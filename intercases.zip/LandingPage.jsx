
import { useState } from 'react';
import { motion } from 'framer-motion';

export default function LandingPage() {
  const [darkMode, setDarkMode] = useState(false);

  return (
    <div className={darkMode ? 'bg-black text-white' : 'bg-white text-black'}>
      <header className="flex justify-between items-center p-6 shadow-md">
        <h1 className="text-3xl font-bold">INTERCASES</h1>
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="px-4 py-2 rounded bg-gray-200 dark:bg-gray-800"
        >
          {darkMode ? '☀️' : '🌙'}
        </button>
      </header>

      <main className="text-center p-10">
        <motion.h2
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-5xl font-bold mb-6"
        >
          ברוכים הבאים ל־INTERCASES
        </motion.h2>

        <p className="text-lg max-w-2xl mx-auto mb-10">
          המקום האידיאלי ללמידה לבגרות — סיכומים, שאלות ותשובות, בגרויות קודמות, גישה נוחה וממשק כמו של Apple. הכל בחינם ובאהבה.
        </p>

        <motion.img
          src="/hero-illustration.svg"
          alt="Learning Illustration"
          className="mx-auto w-full max-w-md mb-10"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.3 }}
        />

        <motion.a
          href="/login"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          className="inline-block bg-black text-white dark:bg-white dark:text-black px-8 py-3 rounded-full text-lg font-semibold shadow-lg transition-all"
        >
          התחבר למערכת
        </motion.a>
      </main>

      <footer className="text-center p-4 text-sm opacity-60">
        © {new Date().getFullYear()} INTERCASES. כל הזכויות שמורות.
      </footer>
    </div>
  );
}
